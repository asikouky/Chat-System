import java.io.*;
import java.net.Socket;
import java.sql.SQLOutput;
import java.util.InputMismatchException;
import java.util.Scanner;

// Application client
public class client {
    private static Socket socket;
    public static void main(String[] args) throws Exception {
        // Adresse et port du serveur
        String name = "";
        String serverAddress;
        do {
            Scanner keyboard = new Scanner(System.in);
            System.out.println("enter the server's IP adress ");
            serverAddress = keyboard.nextLine();
            //String serverAddress = "127.0.0.1";
        }
        while (!isValid(serverAddress));

        int port;
        do {
            Scanner keyboard1 = new Scanner(System.in);
            System.out.println("enter the server's listening Port ");
            try {
                port = keyboard1.nextInt();
            }
            catch(InputMismatchException e){
                port = 0;
            }
            //int port = 5000;;
        }
        while (!(port<=5050 && 5000<=port));

        socket = new Socket(serverAddress, port);
        DataInputStream in = new DataInputStream(socket.getInputStream());
        DataOutputStream out = new DataOutputStream(socket.getOutputStream());
        // Création d'une nouvelle connexion aves le serveur
        System.out.println();
        System.out.format("Serveur lancé sur [%s:%d] ", serverAddress, port);
        String response = in.readUTF();
        System.out.println(response);


        boolean failedToConnect = true;

        while(failedToConnect){
            Scanner keyboard = new Scanner(System.in);
            System.out.println("enter your username ");
            String username = keyboard.nextLine();

            System.out.println("enter your password ");
            String password = keyboard.nextLine();


            out.writeUTF(username); // envoi des proprietes du client
            out.writeUTF(password);

            response = in.readUTF();
            System.out.println("Connexion : "+response);

            System.out.println("réponse obtenue");
            switch (response){
                case "Failed" -> failedToConnect = true;
                case "Success" -> {
                    failedToConnect = false;
                }
                case "Created" -> {
                    failedToConnect = false;
                }
            }
        }
        Thread readThread = new Thread(() -> {
            try {
                while (!socket.isClosed()) {
                    String receivedMessage = in.readUTF();
                    System.out.println(receivedMessage);
                }
            } catch (IOException e) {
                System.out.println("Connexion closed");
            }
        });
        readThread.start();
        System.out.println();
        System.out.println("___________________________________________________");
        System.out.println("Messagerie : ");
        Scanner keyboard = new Scanner(System.in);
        String keyboardInput;
        while (true) {
            keyboardInput = keyboard.nextLine();
            if (keyboardInput.equalsIgnoreCase("exit")) {
                out.writeUTF(keyboardInput);
                break;
            } else if (keyboardInput.length()>200) {
                System.out.println("Message trop long");
            } else {
                out.writeUTF(keyboardInput);
            }
        }


    }

    public static boolean isValid(String adress){
        String[] res = adress.split("\\.");
        if(res.length==4){
            for(String a : res){

                try{
                    int valInt = Integer.parseInt(a);
                    if (!(valInt<256 && 0<=valInt)) return false;
                }
                catch(NumberFormatException e){
                    return false;
                }
            }
            return true;
        }
        return false;
    }
}