
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.ServerSocket;
import java.text.NumberFormat;
import java.util.*;
import java.io.*;
import java.io.File;
import java.io.FileNotFoundException;  // Import this class to handle errors
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.ServerSocket;
import java.text.NumberFormat;
import java.util.InputMismatchException;
import java.util.Scanner;
import java.io.*;
import java.io.File;
import java.io.FileNotFoundException;  // Import this class to handle errors
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;
public class serveur {
    private static ServerSocket Listener; // Application Serveur
    private static Deque<String> messageList;
    private static List<clientHandler> clientHandlers = new ArrayList<>();
    public static List<clientHandler> clientHandlersThreads = new CopyOnWriteArrayList<>();

    public static void main(String[] args) throws Exception {
        // Compteur incrémenté à chaque connexion d'un client au serveur
        int clientNumber = 0;
        // Adresse et port du serveur

        String serverAddress;
        do {
            Scanner keyboard = new Scanner(System.in);
            System.out.println("enter a valid IP adress ");
            serverAddress = keyboard.nextLine();
            //String serverAddress = "127.0.0.1";
        }
        while (!isValid(serverAddress));

        int serverPort;
        do {
            Scanner keyboard1 = new Scanner(System.in);
            System.out.println("enter a listening Port ");
            try {
                serverPort = keyboard1.nextInt();
            }
            catch(InputMismatchException e){
                serverPort = 0;
            };
            //int serverPort = 5000;;
        }
        while (!(serverPort<=5050 && 5000<=serverPort));



        // Création de la connexien pour communiquer ave les, clients
        Listener = new ServerSocket();
        Listener.setReuseAddress(true);
        InetAddress serverIP = InetAddress.getByName(serverAddress);
        // Association de l'adresse et du port à la connexien
        Listener.bind(new InetSocketAddress(serverIP, serverPort));
        System.out.format("The server is running on %s:%d%n", serverAddress, serverPort);
        try {
            // À chaque fois qu'un nouveau client se, connecte, on exécute la fonction
            // run() de l'objet ClientHandler
            while (true) {
                // Important : la fonction accept() est bloquante: attend qu'un prochain client se connecte
                // Une nouvetle connection : on incrémente le compteur clientNumber
                new clientHandler(Listener.accept(), clientNumber++, clientHandlers,messageList).start();
            }
        } finally {
            // Fermeture de la connexion
            Listener.close();
        }
    }

    public static boolean isValid(String adress){
        String[] res = adress.split("\\.");
        if(res.length==4){
            for(String a : res){

                try{
                    int valInt = Integer.parseInt(a);
                    if (!(valInt<256 && 0<=valInt)) return false;
                }
                catch(NumberFormatException e){
                    return false;
                }
            }
            return true;
        }
        return false;
    }

    public static List<clientHandler> getClientHandlers() {
        return clientHandlers;
    }

}
