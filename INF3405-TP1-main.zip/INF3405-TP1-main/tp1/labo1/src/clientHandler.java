import java.io.*;
import java.net.Socket;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;

import static java.lang.System.out;

public class clientHandler extends Thread { // pour traiter la demande de chaque client sur un socket particulier
    private Socket socket;
    private int clientNumber;
    private List<clientHandler> clientsList;
    private Deque<String> messagesList;
    private String username;
    private static final String MESSAGES_FILE_PREFIX = "messages_";
    private DataOutputStream out;
    public clientHandler(Socket socket, int clientNumber, List<clientHandler> clients, Deque<String> messagesList) {
        this.socket = socket;
        this.clientNumber = clientNumber;
        this.clientsList = clients;
        clients.add(this);
        this.messagesList = messagesList;
        try {
            this.out = new DataOutputStream(socket.getOutputStream()); // Initialisation de out
        } catch (IOException e) {
            System.out.println("Error initializing stream: " + e.getMessage());
        }
        System.out.println("New connection with client # " + clientNumber + " at " + socket);
    }
    // Add a setter method for the username
    public void setUsername(String username) {
        this.username = username;
    }
    public void sendMessage(String message) {
        try {
            this.out.writeUTF(message);
        } catch (IOException e) {
            System.out.println("Error sending message to client #" + clientNumber + ": " + e.getMessage());
        }
    }
    // Add a getter method for the username
    public String getUsername() {
        return username;
    }
    public void run() { // Création de thread qui envoi un message à un client
        try {
            serveur.clientHandlersThreads.add(this);
            out.writeUTF("Hello from server - you are client#" + clientNumber); // envoi de message

            // Gestion Reception USERNAME et PASSWORD

            DataInputStream in = new DataInputStream(socket.getInputStream());
            String message = "";
            String finalUsername = "";
            do {
                String receivedUsername = in.readUTF();
                setUsername(receivedUsername);
                String password = in.readUTF();

                System.out.println("Received username : " + username);
                System.out.println("Received password : " + password);
                // Verification dans la base de données
                try {
                    boolean fileCreated = false;
                    String accountFile = "accountFile.txt";
                    File file = new File(accountFile);
                    // Créer le fichier s'il n'existe pas
                    if (!file.exists()) {
                        file.createNewFile();
                        fileCreated = true;
                        System.out.println("The account file was created");
                    }

                    // Lire le fichier pour vérifier l'existence des données
                    FileReader fileReader = new FileReader(file);
                    BufferedReader bufferedReader = new BufferedReader(fileReader);

                    boolean clientFound = false;
                    if (fileCreated) {
                        System.out.println("Client number " + clientNumber +
                                " has created a new profile and the log file");
                        message = "Created";
                        out.writeUTF(message);

                        // Écrire dans le .txt les nouvelles valeurs
                        FileWriter fileWriter = new FileWriter(file, true); // Append mode
                        BufferedWriter bufferedWriter = new BufferedWriter(fileWriter);
                        bufferedWriter.write(username + " , " + password);
                        bufferedWriter.newLine();
                        bufferedWriter.close();
                    } else {
                        String line = bufferedReader.readLine();
                        System.out.println(line);
                        while (line != null) {
                            String[] parts = line.split(",");
                            if (parts.length == 2) {
                                String usernameRed = parts[0].trim();
                                String passwordRed = parts[1].trim();
                                if (usernameRed.equals(username)) {
                                    if (!passwordRed.equals(password)) {
                                        System.out.println("Password and username are not matching");
                                        message = "Failed";
                                        out.writeUTF(message);
                                        clientFound = true;
                                    } else {
                                        System.out.println("Client number " + clientNumber + " has logged in");
                                        message = "Success";
                                        out.writeUTF(message);
                                        clientFound = true;
                                    }
                                }
                            }
                            line = bufferedReader.readLine();
                        }
                        if (!clientFound) {
                            System.out.println("Client number " + clientNumber + " has created a new profile");
                            message = "Created";
                            out.writeUTF(message);

                            // Écrire dans le .txt les nouvelles valeurs
                            FileWriter fileWriter = new FileWriter(file, true); // Append mode
                            BufferedWriter bufferedWriter = new BufferedWriter(fileWriter);
                            bufferedWriter.write(username + " , " + password);
                            bufferedWriter.newLine();
                            bufferedWriter.close();
                        }
                        finalUsername = username;
                    }
                }catch(Exception e) {
                    System.out.println("Error");
                }
            }while(message.equals("Failed"));



            while (!socket.isClosed()) {
                String lastMessages = retrieveLastMessages();
                out.writeUTF(lastMessages);
                String clientMessage = in.readUTF();
                if (clientMessage.equals("exit")) {
                    System.out.println("Client #"+clientNumber+" has disconnected");
                    serveur.clientHandlersThreads.remove(this);
                    socket.close();
                    break;
                }
                else{
                    printMessageToEachClient(clientMessage);
                }
                //System.out.println("Message from client #" + clientNumber + ": " + clientMessage);

                //for (clientHandler client : serveur.clientHandlersThreads) {
                    //if (client != this) {
                        //client.sendMessage(finalUsername+" dit : "+clientMessage);
                    //}
                //}
            }

        } catch (IOException e) {
            System.out.println("Error handling client# " + clientNumber + ": " + e);
        }
    }
    private void printMessageToEachClient(String message){
        // Get the current date and time
        LocalDateTime currentTime = LocalDateTime.now();
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd@HH:mm:ss");
        String formattedDateTime = currentTime.format(formatter);

        // Get the client's address and port
        String clientAddress = socket.getInetAddress().getHostAddress();
        int clientPort = socket.getPort();

        String clientUsername = username;

        // Construct the formatted message
        String formattedMessage = String.format("[%s - %s:%d - %s]: %s", clientUsername, clientAddress, clientPort, formattedDateTime, message);

        // Print the formatted message to the console
        System.out.println(formattedMessage);
        storeMessage(formattedMessage);
        for(clientHandler client: clientsList){
            if (client != this && !client.socket.isClosed()) {
                try {
                    // Send the message to other clients
                    DataOutputStream clientOut = new DataOutputStream(client.socket.getOutputStream());
                    clientOut.writeUTF(formattedMessage);
                } catch (IOException e) {
                    System.out.println("we cannot send the message to" + client.clientNumber + ": " + e);
                }
            }
        }
    }
    private void storeMessage(String message) {
        try (BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter("allMessages.txt", true))) {
            bufferedWriter.write(message + "\n");
            // Read all messages and keep only the last 15
            List<String> messages = readAllMessages();
            int startIndex = Math.max(messages.size() - 15, 0);
            List<String> last15Messages = messages.subList(startIndex, messages.size());


            writeMessages(last15Messages);
        } catch (IOException e) {
            System.out.println("Error storing message for client #" + clientNumber + ": " + e);
        }

    }
    private static List<String> readAllMessages() {
        try {
            return Files.readAllLines(Paths.get("allMessages.txt"));
        } catch (IOException e) {
            e.printStackTrace();
        }
        return new ArrayList<>();
    }
    private static void writeMessages(List<String> messages) {
        try {
            Files.write(Paths.get("allMessages.txt"), messages);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    private String retrieveLastMessages() {
        List<String> last15Messages = readLastMessages();
        return String.join("\n", last15Messages);
    }
    private static List<String> readLastMessages() {
        List<String> messages = readAllMessages();
        int startIndex = Math.max(messages.size() - 15, 0);
        return messages.subList(startIndex, messages.size());
    }
}
